package com.argxment.extraadditions.machines.client;

import com.tterrag.registrate.util.entry.ItemEntry;

import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;

import static com.argxment.extraadditions.ExtraAdditionsCore.EXTRA_ADDITIONS_REGISTRATE;
import static net.minecraftforge.registries.ForgeRegistries.ITEMS;

public class EAItems {

    // Huge thanks to witherschat (monifactory contributor) for allowing me to use the universal circuit textures!

    public static final ItemEntry<Item> GIZMO_WRENCH = EXTRA_ADDITIONS_REGISTRATE
            .item("gizmo_wrench", Item::new)
            .lang("Gizmo Wrench")
            .model((ctx, prov) -> prov.generated(ctx, prov.modLoc("item/tools/gizmo_wrench")))
            .register();

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}