package com.argxment.extraadditions.machines;

import com.gregtechceu.gtceu.api.GTValues;
import net.minecraft.data.recipes.FinishedRecipe;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.fluids.FluidStack;

import java.util.function.Consumer;

import static com.argxment.extraadditions.machines.client.EARecipeTypes.ROCK_PROCESSING;
import static com.gregtechceu.gtceu.api.data.tag.TagPrefix.dust;
import static com.gregtechceu.gtceu.common.data.GTMaterials.*;

public class EARecipes {

    public static void init(Consumer<FinishedRecipe> provider) {
        /*
        //.circuitMeta(int 1 -> 32)
        // placeholders, not the actual recipes
        ASSEMBLY_LINE_RECIPES.recipeBuilder("robust_alloy_materializer")
                .inputItems(GCYMMachines.BLAST_ALLOY_SMELTER, 4)
                .inputItems(CustomTags.ZPM_CIRCUITS, 8)
                .inputItems(plate, TungstenCarbide, 16)
                .inputItems(ENERGY_MODULE, 4)
                .inputItems(ADVANCED_SMD_DIODE, 32)
                .inputItems(ADVANCED_SMD_CAPACITOR, 32)
                .inputItems(ADVANCED_SMD_RESISTOR, 32)
                .inputItems(ADVANCED_SMD_TRANSISTOR, 32)
                .inputItems(ADVANCED_SMD_INDUCTOR, 32)
                // --------------------------------------------------
                .inputFluids(SolderingAlloy.getFluid(576))
                .outputItems(ROBUST_ALLOY_MATERIALIZER)
                .stationResearch(b -> b
                        .researchStack(GCYMMachines.BLAST_ALLOY_SMELTER.asStack())
                        .CWUt(128)
                        .EUt(GTValues.VA[GTValues.ZPM]))
                .EUt(GTValues.VA[GTValues.UV])
                .duration(1500)
                .save(provider);

        ASSEMBLY_LINE_RECIPES.recipeBuilder("advanced_fusion_reactor_mk1")
                .inputItems(SUPERCONDUCTING_COIL.asStack(), 4)
                .inputItems(CustomTags.ZPM_CIRCUITS, 8)
                .inputItems(plateDouble, Plutonium241, 4)
                .inputItems(plateDouble, Osmiridium, 4)
                .inputItems(FIELD_GENERATOR_IV, 8)
                .inputItems(ULTRA_HIGH_POWER_INTEGRATED_CIRCUIT, 64)
                .inputItems(wireGtSingle, IndiumTinBariumTitaniumCuprate, 64)
                .inputFluids(SolderingAlloy.getFluid(L * 16))
                .inputFluids(NiobiumTitanium.getFluid(L * 16))
                .outputItems(ADVANCED_FUSION_REACTOR[LuV].asStack())
                .duration(800)
                .EUt(GTValues.VA[GTValues.LuV])
                .save(provider);

        ASSEMBLY_LINE_RECIPES.recipeBuilder("advanced_fusion_reactor_mk2")
                .inputItems(FUSION_COIL.asStack(), 4)
                .inputItems(CustomTags.UV_CIRCUITS, 8)
                .inputItems(plateDouble, Naquadria, 4)
                .inputItems(plateDouble, Europium, 4)
                .inputItems(FIELD_GENERATOR_LuV, 8)
                .inputItems(ULTRA_HIGH_POWER_INTEGRATED_CIRCUIT, 64)
                .inputItems(ULTRA_HIGH_POWER_INTEGRATED_CIRCUIT, 32)
                .inputItems(wireGtSingle, UraniumRhodiumDinaquadide, 64)
                .inputFluids(SolderingAlloy.getFluid(L * 16))
                .inputFluids(VanadiumGallium.getFluid(L * 16))
                .outputItems(ADVANCED_FUSION_REACTOR[ZPM].asStack())
                .duration(2000)
                .EUt(GTValues.VA[GTValues.ZPM])
                .save(provider);

        ASSEMBLY_LINE_RECIPES.recipeBuilder("advanced_fusion_reactor_mk3")
                .inputItems(FUSION_COIL.asStack(), 4)
                .inputItems(CustomTags.UHV_CIRCUITS, 8)
                .inputItems(QUANTUM_STAR, 8)
                .inputItems(plateDouble, Americium, 8)
                .inputItems(FIELD_GENERATOR_ZPM, 8)
                .inputItems(ULTRA_HIGH_POWER_INTEGRATED_CIRCUIT, 64)
                .inputItems(ULTRA_HIGH_POWER_INTEGRATED_CIRCUIT, 64)
                .inputItems(wireGtSingle, EnrichedNaquadahTriniumEuropiumDuranide, 64)
                .inputFluids(SolderingAlloy.getFluid(L * 16))
                .inputFluids(YttriumBariumCuprate.getFluid(L * 16))
                .outputItems(ADVANCED_FUSION_REACTOR[UV].asStack())
                .duration(3000)
                .EUt(GTValues.VA[GTValues.UV])
                .save(provider);

         */

        ROCK_PROCESSING.recipeBuilder("deepslate_processing")
                .inputItems(new ItemStack(Blocks.DEEPSLATE), 256)
                .perTick(true)
                    .inputFluids(DrillingFluid.getFluid(5))
                .perTick(false)
                .outputItemsRanged(dust, Potassium, UniformInt.of(1,128))
                .outputItemsRanged(dust, Magnesium, UniformInt.of(1,128))
                .outputItemsRanged(dust, Aluminium, UniformInt.of(1,128))
                .outputItemsRanged(dust, Silicon, UniformInt.of(1,128))
                .outputFluidsRanged(
                        new FluidStack(Fluorine.getFluid(), 1000),
                            UniformInt.of(1000, 16000)
                )
                .outputFluidsRanged(
                        new FluidStack(Oxygen.getFluid(), 1000),
                            UniformInt.of(1000, 16000)
                )
                .duration(5000)
                .EUt(GTValues.VA[GTValues.LuV])
                .save(provider);

        ROCK_PROCESSING.recipeBuilder("andesite_processing")
                .inputItems(new ItemStack(Blocks.ANDESITE), 256)
                .perTick(true)
                    .inputFluids(DrillingFluid.getFluid(5))
                .perTick(false)
                .outputItemsRanged(dust, Magnesium, UniformInt.of(1,128))
                .outputItemsRanged(dust, Silicon, UniformInt.of(1,128))
                .outputFluidsRanged(
                        new FluidStack(Hydrogen.getFluid(), 1000),
                        UniformInt.of(1000, 16000)
                )
                .outputFluidsRanged(
                        new FluidStack(Oxygen.getFluid(), 1000),
                        UniformInt.of(1000, 16000)
                )
                .duration(5000)
                .EUt(GTValues.VA[GTValues.LuV])
                .save(provider);

        ROCK_PROCESSING.recipeBuilder("diorite_processing")
                .inputItems(new ItemStack(Blocks.DIORITE), 256)
                .perTick(true)
                    .inputFluids(DrillingFluid.getFluid(5))
                .perTick(false)
                .outputItemsRanged(dust, Sodium, UniformInt.of(1,96))
                .outputItemsRanged(dust, Sulfur, UniformInt.of(1,64))
                .outputFluidsRanged(
                        new FluidStack(Water.getFluid(), 1000),
                        UniformInt.of(1000, 64000)
                )
                .outputFluidsRanged(
                        new FluidStack(Oxygen.getFluid(), 1000),
                        UniformInt.of(1000, 16000)
                )
                .duration(5000)
                .EUt(GTValues.VA[GTValues.LuV])
                .save(provider);

        ROCK_PROCESSING.recipeBuilder("obsidian_processing")
                .inputItems(new ItemStack(Blocks.OBSIDIAN), 256)
                .perTick(true)
                    .inputFluids(DrillingFluid.getFluid(5))
                .perTick(false)
                .outputItemsRanged(dust, Magnesium, UniformInt.of(1,96))
                .outputItemsRanged(dust, Iron, UniformInt.of(1,96))
                .outputItemsRanged(dust, Silicon, UniformInt.of(1,64))
                .outputFluidsRanged(
                        new FluidStack(Oxygen.getFluid(), 1000),
                        UniformInt.of(1000, 16000)
                )
                .duration(5000)
                .EUt(GTValues.VA[GTValues.LuV])
                .save(provider);
    }
}
